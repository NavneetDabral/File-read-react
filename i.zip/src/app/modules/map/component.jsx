import React ,{ useState } from 'react';
import ReactMapGL from 'react-map-gl';
import {REACT_APP_TOKEN} from '../../config';
import 'mapbox-gl/dist/mapbox-gl.css'
const Component =(props)=>{
   

   console.log(props.tableData);
   
   const [viewport, setViewPort ] = useState({
      width:"100%",
      height:"90vh",
      latitude:12.92415,
      longitude:77.67229,
      zoom:8
    })
  
    const _onViewportChange = viewport => setViewPort({...viewport, transitionDuration: 100 })
    
    
    return(
     <div className="map-f">

    
     <ReactMapGL
     {...viewport}
      mapboxApiAccessToken={REACT_APP_TOKEN}
      mapStyle="mapbox://styles/mapbox/dark-v8"
      onViewportChange={_onViewportChange}
    
    />
     </div>
     
    )  
}

export default Component;