  import { ADD_COLUMNS} from '../../../actions'
  import postData from '../http-methods/postData';
  export const addCsv =(data)=> dispatch=>{

     console.log("dispatched csv");
      
     postData("http://localhost:5000/save-data",{
       data
     }).then((res)=>{
        console.log(res);
     }

     )
     .catch((err)=>{
       console.log(err);
     })
     
  }


  export const addNoOfColumn =(data)=> dispatch=>{

    console.log("dispatched no of col");
   dispatch({
       type:ADD_COLUMNS,
       payload:data

       })

 }