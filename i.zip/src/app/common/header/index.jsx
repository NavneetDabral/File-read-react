import React from 'react';
import { NavLink as Link } from 'react-router-dom'
 
const Component = (props) =>{
    
    return(
   
        <div className="header">
            <div>
            <Link  to='/'><img alt="logo" src="https://uploads-ssl.webflow.com/5d4c23635c89806338bf3891/5d4dae6d7ec36649d4c88cee_Asset%2015.png" ></img></Link></div> 
            <div>
              <nav>
               <Link activeStyle={{color:"#00C853" ,borderColor:"#00C853",opacity:1}}  to='/analytics'>Analytics</Link>
               <Link activeStyle={{color:"#00C853",borderColor:"#00C853" ,opacity:1}}  to='/locations'>locations</Link>
              </nav>
              </div>  
            <div>hola</div>  

        </div>

    )

}

export default Component;
