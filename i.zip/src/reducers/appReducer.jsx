import {initialState} from '../index'
import {ADD_CSV_DATA ,ADD_COLUMNS} from '../actions';

function AppReducer(state = initialState.appreducer, action) {
    switch (action.type) {
      case ADD_CSV_DATA:
        return Object.assign({}, state, {
          appState: {
            ...state.appState, 
           locationData:action.payload
          }
        })
        

        case ADD_COLUMNS:
          return Object.assign({}, state, {
            appState: {
              ...state.appState, 
             noOfCol:action.payload
            }
          })
          
        
      
      
      default:
        return state
    }
  }
  

  export default AppReducer;