import React from 'react';

const Component =(props)=>{
   
   console.log(props.tableData);
 
   
    return(
        <div>
        {
           props.tableData ? <div>
            hi
         </div> :<div> hey gotcha</div>


        }
        
           
        </div>
     

   )

};

export default Component