import React  from 'react';

const Component =(props)=>{
   

   console.log(props.tableData);
   
   
    
    
    return(
     <div className="flex-container">
     
       <div>

       hi
       </div>
       <div>
      hi

       </div>
       <div>
      hi

       </div>
       <div>
      hi

       </div>


     </div>
     
    )  
}

export default Component;