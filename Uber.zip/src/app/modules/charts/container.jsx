import component from './component';
import {connect} from 'react-redux';

const mapStateToProps =(state) =>({
   
 tableData :state.appreducer.appState.locationData   

})


const mapDispatchToProps =(dispatch) =>({
 
 


})

export default connect(mapStateToProps,mapDispatchToProps)(component);


