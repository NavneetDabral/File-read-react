import React  from 'react';
import {REACT_APP_TOKEN} from '../../config';
import 'mapbox-gl/dist/mapbox-gl.css'
import DeckGL from '@deck.gl/react';
import {ArcLayer} from '@deck.gl/layers';
import MapGL, {Marker, Popup, NavigationControl, FullscreenControl} from 'react-map-gl';
import CityPin from './city-pin';
import CityInfo from './city-info';
import CITIES from './cities.json';

const TOKEN = REACT_APP_TOKEN; // Set your mapbox token here
const fullscreenControlStyle = {
  position: 'absolute',
  top: 0,
  left: 0,
  padding: '10px'
};

const navStyle = {
  position: 'absolute',
  top: 36,
  left: 0,
  padding: '10px'
};

class Map extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      viewport: {
        height:"600px",
        width:"100%",
        latitude: 40.6643,
        longitude: -73.9385,
        zoom: 13,
        bearing:-60,
        pitch: 60
      },
      popupInfo: null
    };
  }

  _updateViewport = viewport => {
    this.setState({viewport});
  };

  _renderCityMarker = (city, index) => {
    return (
      <Marker key={`marker-${index}`} longitude={city.longitude} latitude={city.latitude}>
        <CityPin size={20} onClick={() => this.setState({popupInfo: city})} />
      </Marker>
    );
  };

  _renderPopup() {
    const {popupInfo} = this.state;

    return (
      popupInfo && (
        <Popup
          tipSize={3}
          anchor="top"
          longitude={popupInfo.longitude}
          latitude={popupInfo.latitude}
          closeOnClick={false}
          onClose={() => this.setState({popupInfo: null})}
        >
          <CityInfo info={popupInfo} />
        </Popup>
      )
    );
  }

  render() {
    const {viewport} = this.state;
    // const layers = [
    //   new LineLayer({id: 'line-layer', data, stroked: false,
    //   strokeWidth: 4,
    //   getSourceColor: x => [0, 0, 255],
    //   getTargetColor: x => [0, 255, 0],
    //   })];
    return (
    
      <MapGL
        {...viewport}
        // mapStyle="mapbox://styles/mapbox/dark-v9"
        onViewportChange={this._updateViewport}
        mapboxApiAccessToken={TOKEN}
      >
       <DeckGL
          viewState={viewport}
          layers={[
            new ArcLayer({
              data: [
                {
                  sourcePosition: [40.6643, -73.9385], 
                  targetPosition: [34.0194, -118.4108]
                }
              ],
              strokeWidth: 2,
              getSourceColor: x => [255, 0, 255],
              getTargetColor: x => [0, 255, 0]
            })
          ]}
        />
        {CITIES.map(this._renderCityMarker)}

        {this._renderPopup()}

        <div className="fullscreen" style={fullscreenControlStyle}>
          <FullscreenControl />
        </div>
        <div className="nav" style={navStyle}>
          <NavigationControl />
        </div>
      </MapGL>
    );
  }
}

export default Map;