import React ,{useState} from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import axios from 'axios';

const useStyles = makeStyles(theme => ({
    button: {
      margin: theme.spacing(1),
      padding:theme.spacing(10),
      color:"#283593",
      fontSize:"12px",
      fontWeight:"700",
      borderRadius:"0.4em"
    },
    input: {
      display: 'none',
    },
  }));
  
let Component=(props) => {
    const classes = useStyles();
    const[file ,setFile]=useState(null);


const onChangeHandler=event=>{

  console.log(event.target.files[0]);  
  setFile(event.target.files[0]);
    
  

  
}
  
const onClickHandler = (e) => {
  e.preventDefault();
   console.log(file);
  const data = new FormData()
  data.append('my-file',file)
  axios.post("http://localhost:5000/upload-csv/data", data)
  .then((res)=>{
       console.log(res);
  })

}


  return (   
         <div className="file-upload">
              
              <form>
             
              <input name="my-file" type="file" onChange={onChangeHandler}></input>

           <Button  onClick={onClickHandler}  variant="outlined" color="primary">
             Submit
           </Button>
              </form>
         
     
        
        </div>

  );
  }

  export default Component;