import component from './component';
import {connect} from 'react-redux';
import {addCsv,addNoOfColumn} from './actions';

const mapStateToProps =(state) =>({
    
})


const mapDispatchToProps =(dispatch) =>({
 
    addCsvMapped :(data) => dispatch(addCsv(data)),
    addNoOfColumnMapped:(data) =>dispatch(addNoOfColumn(data))


})

export default connect(mapStateToProps,mapDispatchToProps)(component);


