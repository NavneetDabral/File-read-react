import React from 'react';
import { NavLink as Link } from 'react-router-dom'
 
const Component = (props) =>{
    
    return(
   
        <div className="header">
            <div>
            <Link  to='/'><img alt="logo" src="" ></img></Link></div> 
            <div>
              <nav>
               <Link activeStyle={{color:"#00C853" ,borderColor:"#00C853",opacity:1}}  to='/analytics'>Analytics</Link>
               <Link activeStyle={{color:"#00C853",borderColor:"#00C853" ,opacity:1}}  to='/locations'>locations</Link>
              </nav>
              </div>  
            <div>hola</div>  

        </div>

    )

}

export default Component;
