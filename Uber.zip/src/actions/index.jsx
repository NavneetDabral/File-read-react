
export const ADD_CSV_DATA ="add_csv_data";
export const ADD_COLUMNS="add_columns";