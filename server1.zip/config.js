const Password =encodeURIComponent("emUUZ$AZVyA$AW5");
const URI = "mongodb+srv://navneet:"+Password+"@cluster0-atefw.mongodb.net/test?retryWrites=true&w=majority";
module.exports=URI;