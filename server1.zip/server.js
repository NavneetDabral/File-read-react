const express = require('express');
const app = express();
const bodyParser=require('body-parser');
const cors =require('cors');
const connectDb= require('./connect-mongo');
const Router=express.Router;
const router = new Router();
const multer = require('multer');
const fs = require('fs');
const csv=require('fast-csv');
const catSchema =require('./schemas/user-data');
const csvSchema =require('./schemas/csv');
const upload = multer({ dest: 'tmp/csv/' });
app.use(bodyParser.json());
app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));
router.use(cors());
app.use('/upload-csv', router);



//database connection
connectDb();

//app routes

router.post('/data',upload.single('my-file'),async (req,res)=>{

try{
  const fileRows = [];
  csv.fromPath(req.file.path)
   .on("data", function (data) {
     fileRows.push(data); // push each row
   })
   .on("end", async function () {
     
       let i=1;
       console.log(fileRows.length);
      
      while(i!=fileRows.length){
       
            

       let dataSchema=new csvSchema({
         "id" :`${fileRows[i][0]}`,
         "user_id" :`${fileRows[i][1]}`,
         "vehical_model_id" :`${fileRows[i][2]}`,
         "package_id" :`${fileRows[i][3]}`,
         "travel_type" :`${fileRows[i][4]}`,
         "from_area_id" :`${fileRows[i][5]}`,
         "to_area_id" :`${fileRows[i][6]}`,
         "from_city_id" :`${fileRows[i][7]}`,
         "to_city_id" :`${fileRows[i][8]}`,
         "from_data" :`${fileRows[i][9]}`,
         "to_data" :`${fileRows[i][10]}`,
         "online_booking" :`${fileRows[i][11]}`,
         "mobile_booking" :`${fileRows[i][12]}`,
         "booking_created" :`${fileRows[i][13]}`,
         "from_lat" :`${fileRows[i][14]}`,
         "from_long" :`${fileRows[i][15]}`,
         "to_lat" :`${fileRows[i][16]}`,
         "to_long" :`${fileRows[i][17]}`,
         "car_cancel" :`${fileRows[i][18]}`
       });   
       
      let results = await dataSchema.save(function(err,data)
        {
       if(err)
       {
           console.log(err);
       }
       console.log("Success"+i);
   })
       
 
       i++;
      }
 
     fs.unlinkSync(req.file.path);   // remove temp file
     //process "fileRows" and respond
res.json({status:"ok"});
   })
  
}
catch(err){
  console.error(err);
}

});




//test db write http://localhost:5000/test


app.get('/test', async (req,res)=>{
  try{
   let dataSchema=new catSchema({"name":"nasdas"});
   dataSchema.save(function(err,data)
   {
       if(err)
       {
           res.json({err:1,msg:'Registration Error'})
       }
       res.sendStatus(200);
       console.log("Success");
   })
  }
  catch(err){
      console.err(err);
  }  
 
 });


 


app.listen(5000, function () {
    console.log('Dev app listening on port 5000!');
});