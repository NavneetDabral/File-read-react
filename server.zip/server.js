const express = require('express');
const bodyParser=require('body-parser');
const  cors =require('cors');
const fs = require('fs');
const multer = require('multer');
const csv = require('fast-csv');
const upload = multer({ dest: 'tmp/csv/' });
const app = express();
const Router = express.Router;
const router = new Router();
app.use('/upload-csv', router);
const  sqlite3 = require('sqlite3').verbose()
app.use(bodyParser.json());
app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));
router.use(cors());

const db = new sqlite3.Database('./database/geo.db', (err) => {
    if (err) {
      return console.error(err.message);
    }
    console.log('Connected to the geo SQlite database.');
  })


 db.run('CREATE TABLE IF NOT EXISTS Geodata(id TEXT,user_id TEXT,vehical_model_id TEXT,package_id TEXT,travel_type TEXT,from_area_id TEXT,to_area_id TEXT,from_city_id TEXT,to_city_id TEXT,from_data TEXT,to_data TEXT,online_booking TEXT,mobile_booking TEXT,booking_created TEXT,from_lat TEXT,from_long TEXT,to_lat TEXT,to_long TEXT,car_cancel TEXT)');

 router.post('/data',upload.single('my-file'), async (req,res)=>{
    const fileRows = [];
   
    
    csv.fromPath(req.file.path)
    .on("data", function (data) {
      fileRows.push(data); // push each row
    })
    .on("end", function () {
      console.log(fileRows);
      
      let i=1 ,k=0;
      let syntaxpot = fileRows[0].map((value) => '?').join(',');
        let sql = 'INSERT INTO Geodata(id,user_id,vehical_model_id,package_id,travel_type,from_area_id,to_area_id,from_city_id,to_city_id,from_data,to_data,online_booking,mobile_booking,booking_created,from_lat,from_long,to_lat,to_long,car_cancel) VALUES '+ '('+ syntaxpot+')';
        console.log(sql);
        console.log(fileRows.length);
       while(i!=fileRows.length){
       var x = new Date();
       console.log("NN "+x.getTime());
        let p= await db.run(sql,fileRows[i], function(err) {
         var u = new Date();
         console.log("Db "+(u.getTime()-x.getTime()));
        if (err) {
            k++;
            return console.error(err);
        }
        console.log(`Rows inserted`);
        }); 

        i++;
       }
    console.log(k);
      fs.unlinkSync(req.file.path);   // remove temp file
      //process "fileRows" and respond
    })

    let data={
        "hi":"1"
    }
  res.json(data)

});


app.get('/save-data',(req,res)=>{

console.log(req.body);
   
res.json({"data":1});

 })


 


app.listen(5000, function () {
    console.log('Dev app listening on port 5000!');
});